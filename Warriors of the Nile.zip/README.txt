By using this library, you agree to be bound by the terms and conditions of the license you can find in license.txt (CC BY-NC-SA 3.0).

UnityL10nTool uses AssetsTools (see https://github.com/DerPopo/UABE, CC BY-NC-SA 3.0) and AssetsTools related libraries and replacing icon resources in EXE and DLL files (external Executable https://www.codeproject.com/Articles/30644/Replacing-ICON-resources-in-EXE-and-DLL-files, GPLv3).

Unity is a registered trademark of Unity Technologies. The creator of this library is in no way affiliated with Unity Technologies.

# For compile
Make sure configuration and platform to Release and x86.
